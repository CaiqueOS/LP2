﻿
namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHorista));
            this.lblmatricula = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.lblsalarioporhora = new System.Windows.Forms.Label();
            this.lblnumerodehoras = new System.Windows.Forms.Label();
            this.lbldataentrada = new System.Windows.Forms.Label();
            this.lbldiasdefaltas = new System.Windows.Forms.Label();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtsalarioporhora = new System.Windows.Forms.TextBox();
            this.txtnumerodehoras = new System.Windows.Forms.TextBox();
            this.txtdataentrada = new System.Windows.Forms.TextBox();
            this.txtdiasdefaltas = new System.Windows.Forms.TextBox();
            this.btninstanciar = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.btnclean = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.BackColor = System.Drawing.Color.Thistle;
            this.lblmatricula.ForeColor = System.Drawing.Color.DimGray;
            this.lblmatricula.Location = new System.Drawing.Point(45, 522);
            this.lblmatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(91, 25);
            this.lblmatricula.TabIndex = 0;
            this.lblmatricula.Text = "Matrícula";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.BackColor = System.Drawing.Color.Thistle;
            this.lblnome.ForeColor = System.Drawing.Color.DimGray;
            this.lblnome.Location = new System.Drawing.Point(45, 219);
            this.lblnome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(64, 25);
            this.lblnome.TabIndex = 1;
            this.lblnome.Text = "Nome";
            // 
            // lblsalarioporhora
            // 
            this.lblsalarioporhora.AutoSize = true;
            this.lblsalarioporhora.BackColor = System.Drawing.Color.Thistle;
            this.lblsalarioporhora.ForeColor = System.Drawing.Color.DimGray;
            this.lblsalarioporhora.Location = new System.Drawing.Point(45, 333);
            this.lblsalarioporhora.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalarioporhora.Name = "lblsalarioporhora";
            this.lblsalarioporhora.Size = new System.Drawing.Size(153, 25);
            this.lblsalarioporhora.TabIndex = 2;
            this.lblsalarioporhora.Text = "Salário por Hora";
            // 
            // lblnumerodehoras
            // 
            this.lblnumerodehoras.AutoSize = true;
            this.lblnumerodehoras.BackColor = System.Drawing.Color.Thistle;
            this.lblnumerodehoras.ForeColor = System.Drawing.Color.DimGray;
            this.lblnumerodehoras.Location = new System.Drawing.Point(45, 395);
            this.lblnumerodehoras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnumerodehoras.Name = "lblnumerodehoras";
            this.lblnumerodehoras.Size = new System.Drawing.Size(165, 25);
            this.lblnumerodehoras.TabIndex = 3;
            this.lblnumerodehoras.Text = "Número de Horas";
            // 
            // lbldataentrada
            // 
            this.lbldataentrada.AutoSize = true;
            this.lbldataentrada.BackColor = System.Drawing.Color.Thistle;
            this.lbldataentrada.ForeColor = System.Drawing.Color.DimGray;
            this.lbldataentrada.Location = new System.Drawing.Point(45, 275);
            this.lbldataentrada.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldataentrada.Name = "lbldataentrada";
            this.lbldataentrada.Size = new System.Drawing.Size(236, 25);
            this.lbldataentrada.TabIndex = 4;
            this.lbldataentrada.Text = "Data Entrada na Empresa";
            // 
            // lbldiasdefaltas
            // 
            this.lbldiasdefaltas.AutoSize = true;
            this.lbldiasdefaltas.BackColor = System.Drawing.Color.Thistle;
            this.lbldiasdefaltas.ForeColor = System.Drawing.Color.DimGray;
            this.lbldiasdefaltas.Location = new System.Drawing.Point(45, 458);
            this.lbldiasdefaltas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldiasdefaltas.Name = "lbldiasdefaltas";
            this.lbldiasdefaltas.Size = new System.Drawing.Size(136, 25);
            this.lbldiasdefaltas.TabIndex = 5;
            this.lbldiasdefaltas.Text = "Dias de Faltas";
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(289, 522);
            this.txtmatricula.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(247, 30);
            this.txtmatricula.TabIndex = 6;
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(117, 219);
            this.txtnome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(419, 30);
            this.txtnome.TabIndex = 1;
            // 
            // txtsalarioporhora
            // 
            this.txtsalarioporhora.Location = new System.Drawing.Point(289, 328);
            this.txtsalarioporhora.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtsalarioporhora.Name = "txtsalarioporhora";
            this.txtsalarioporhora.Size = new System.Drawing.Size(247, 30);
            this.txtsalarioporhora.TabIndex = 3;
            // 
            // txtnumerodehoras
            // 
            this.txtnumerodehoras.Location = new System.Drawing.Point(289, 390);
            this.txtnumerodehoras.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtnumerodehoras.Name = "txtnumerodehoras";
            this.txtnumerodehoras.Size = new System.Drawing.Size(247, 30);
            this.txtnumerodehoras.TabIndex = 4;
            // 
            // txtdataentrada
            // 
            this.txtdataentrada.Location = new System.Drawing.Point(289, 275);
            this.txtdataentrada.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtdataentrada.Name = "txtdataentrada";
            this.txtdataentrada.Size = new System.Drawing.Size(247, 30);
            this.txtdataentrada.TabIndex = 2;
            // 
            // txtdiasdefaltas
            // 
            this.txtdiasdefaltas.Location = new System.Drawing.Point(289, 458);
            this.txtdiasdefaltas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtdiasdefaltas.Name = "txtdiasdefaltas";
            this.txtdiasdefaltas.Size = new System.Drawing.Size(247, 30);
            this.txtdiasdefaltas.TabIndex = 5;
            // 
            // btninstanciar
            // 
            this.btninstanciar.BackColor = System.Drawing.Color.Thistle;
            this.btninstanciar.ForeColor = System.Drawing.Color.DimGray;
            this.btninstanciar.Location = new System.Drawing.Point(50, 612);
            this.btninstanciar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btninstanciar.Name = "btninstanciar";
            this.btninstanciar.Size = new System.Drawing.Size(175, 40);
            this.btninstanciar.TabIndex = 7;
            this.btninstanciar.Text = "Instanciar Horista";
            this.btninstanciar.UseVisualStyleBackColor = false;
            this.btninstanciar.Click += new System.EventHandler(this.btninstanciar_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Thistle;
            this.btnback.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnback.ForeColor = System.Drawing.Color.DimGray;
            this.btnback.Location = new System.Drawing.Point(424, 132);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(89, 38);
            this.btnback.TabIndex = 9;
            this.btnback.Text = "Voltar";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnclean
            // 
            this.btnclean.BackColor = System.Drawing.Color.Thistle;
            this.btnclean.ForeColor = System.Drawing.Color.DimGray;
            this.btnclean.Location = new System.Drawing.Point(327, 608);
            this.btnclean.Name = "btnclean";
            this.btnclean.Size = new System.Drawing.Size(186, 44);
            this.btnclean.TabIndex = 8;
            this.btnclean.Text = "Limpar";
            this.btnclean.UseVisualStyleBackColor = false;
            this.btnclean.Click += new System.EventHandler(this.btnclean_Click);
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(564, 738);
            this.Controls.Add(this.btnclean);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btninstanciar);
            this.Controls.Add(this.txtdiasdefaltas);
            this.Controls.Add(this.txtdataentrada);
            this.Controls.Add(this.txtnumerodehoras);
            this.Controls.Add(this.txtsalarioporhora);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.lbldiasdefaltas);
            this.Controls.Add(this.lbldataentrada);
            this.Controls.Add(this.lblnumerodehoras);
            this.Controls.Add(this.lblsalarioporhora);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.lblmatricula);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FloralWhite;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(582, 785);
            this.MinimumSize = new System.Drawing.Size(582, 785);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.Load += new System.EventHandler(this.frmHorista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblsalarioporhora;
        private System.Windows.Forms.Label lblnumerodehoras;
        private System.Windows.Forms.Label lbldataentrada;
        private System.Windows.Forms.Label lbldiasdefaltas;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtsalarioporhora;
        private System.Windows.Forms.TextBox txtnumerodehoras;
        private System.Windows.Forms.TextBox txtdataentrada;
        private System.Windows.Forms.TextBox txtdiasdefaltas;
        private System.Windows.Forms.Button btninstanciar;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnclean;
    }
}