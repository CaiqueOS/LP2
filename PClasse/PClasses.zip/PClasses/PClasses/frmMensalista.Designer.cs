﻿
namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMensalista));
            this.lblmatricula = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.lblsalario = new System.Windows.Forms.Label();
            this.lbldataentrada = new System.Windows.Forms.Label();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtsalariomensal = new System.Windows.Forms.TextBox();
            this.txtdataentrada = new System.Windows.Forms.TextBox();
            this.btninstancia = new System.Windows.Forms.Button();
            this.btnparametros = new System.Windows.Forms.Button();
            this.btnclean = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.BackColor = System.Drawing.Color.Thistle;
            this.lblmatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmatricula.ForeColor = System.Drawing.Color.DimGray;
            this.lblmatricula.Location = new System.Drawing.Point(33, 424);
            this.lblmatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(91, 25);
            this.lblmatricula.TabIndex = 0;
            this.lblmatricula.Text = "Matrícula";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.BackColor = System.Drawing.Color.Thistle;
            this.lblnome.ForeColor = System.Drawing.Color.DimGray;
            this.lblnome.Location = new System.Drawing.Point(33, 241);
            this.lblnome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(64, 25);
            this.lblnome.TabIndex = 1;
            this.lblnome.Text = "Nome";
            // 
            // lblsalario
            // 
            this.lblsalario.AutoSize = true;
            this.lblsalario.BackColor = System.Drawing.Color.Thistle;
            this.lblsalario.ForeColor = System.Drawing.Color.DimGray;
            this.lblsalario.Location = new System.Drawing.Point(33, 365);
            this.lblsalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalario.Name = "lblsalario";
            this.lblsalario.Size = new System.Drawing.Size(142, 25);
            this.lblsalario.TabIndex = 2;
            this.lblsalario.Text = "Salário Mensal";
            // 
            // lbldataentrada
            // 
            this.lbldataentrada.AutoSize = true;
            this.lbldataentrada.BackColor = System.Drawing.Color.Thistle;
            this.lbldataentrada.ForeColor = System.Drawing.Color.DimGray;
            this.lbldataentrada.Location = new System.Drawing.Point(33, 301);
            this.lbldataentrada.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldataentrada.Name = "lbldataentrada";
            this.lbldataentrada.Size = new System.Drawing.Size(236, 25);
            this.lbldataentrada.TabIndex = 3;
            this.lbldataentrada.Text = "Data Entrada na Empresa";
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(289, 421);
            this.txtmatricula.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(237, 30);
            this.txtmatricula.TabIndex = 4;
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(105, 241);
            this.txtnome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(421, 30);
            this.txtnome.TabIndex = 1;
            // 
            // txtsalariomensal
            // 
            this.txtsalariomensal.Location = new System.Drawing.Point(289, 360);
            this.txtsalariomensal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtsalariomensal.Name = "txtsalariomensal";
            this.txtsalariomensal.Size = new System.Drawing.Size(237, 30);
            this.txtsalariomensal.TabIndex = 3;
            // 
            // txtdataentrada
            // 
            this.txtdataentrada.Location = new System.Drawing.Point(289, 298);
            this.txtdataentrada.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtdataentrada.Name = "txtdataentrada";
            this.txtdataentrada.Size = new System.Drawing.Size(237, 30);
            this.txtdataentrada.TabIndex = 2;
            // 
            // btninstancia
            // 
            this.btninstancia.BackColor = System.Drawing.Color.Thistle;
            this.btninstancia.ForeColor = System.Drawing.Color.DimGray;
            this.btninstancia.Location = new System.Drawing.Point(38, 494);
            this.btninstancia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btninstancia.Name = "btninstancia";
            this.btninstancia.Size = new System.Drawing.Size(233, 62);
            this.btninstancia.TabIndex = 5;
            this.btninstancia.Text = "Instanciar Mensalista";
            this.btninstancia.UseVisualStyleBackColor = false;
            this.btninstancia.Click += new System.EventHandler(this.btninstancia_Click);
            // 
            // btnparametros
            // 
            this.btnparametros.BackColor = System.Drawing.Color.Thistle;
            this.btnparametros.ForeColor = System.Drawing.Color.DimGray;
            this.btnparametros.Location = new System.Drawing.Point(317, 494);
            this.btnparametros.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnparametros.Name = "btnparametros";
            this.btnparametros.Size = new System.Drawing.Size(209, 62);
            this.btnparametros.TabIndex = 6;
            this.btnparametros.Text = "Instanciar Mensalista passando parâmetros ";
            this.btnparametros.UseVisualStyleBackColor = false;
            this.btnparametros.Click += new System.EventHandler(this.btnparametros_Click);
            // 
            // btnclean
            // 
            this.btnclean.BackColor = System.Drawing.Color.Thistle;
            this.btnclean.ForeColor = System.Drawing.Color.DimGray;
            this.btnclean.Location = new System.Drawing.Point(185, 597);
            this.btnclean.Name = "btnclean";
            this.btnclean.Size = new System.Drawing.Size(209, 62);
            this.btnclean.TabIndex = 7;
            this.btnclean.Text = "Limpar";
            this.btnclean.UseVisualStyleBackColor = false;
            this.btnclean.Click += new System.EventHandler(this.btnclean_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Thistle;
            this.btnback.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnback.ForeColor = System.Drawing.Color.DimGray;
            this.btnback.Location = new System.Drawing.Point(414, 140);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(112, 56);
            this.btnback.TabIndex = 8;
            this.btnback.Text = "Voltar";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(564, 738);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnclean);
            this.Controls.Add(this.btnparametros);
            this.Controls.Add(this.btninstancia);
            this.Controls.Add(this.txtdataentrada);
            this.Controls.Add(this.txtsalariomensal);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.lbldataentrada);
            this.Controls.Add(this.lblsalario);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.lblmatricula);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(582, 785);
            this.MinimumSize = new System.Drawing.Size(582, 785);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblsalario;
        private System.Windows.Forms.Label lbldataentrada;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtsalariomensal;
        private System.Windows.Forms.TextBox txtdataentrada;
        private System.Windows.Forms.Button btninstancia;
        private System.Windows.Forms.Button btnparametros;
        private System.Windows.Forms.Button btnclean;
        private System.Windows.Forms.Button btnback;
    }
}